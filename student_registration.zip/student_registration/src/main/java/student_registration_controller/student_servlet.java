package student_registration_controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import student_registration.student_database;

import java.io.IOException;

import javax.servlet.RequestDispatcher;

/**
 * Servlet implementation class student_servlet
 * 
 */
@WebServlet("/register")
public class student_servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private student_database db = new student_database();
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public student_servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		jakarta.servlet.RequestDispatcher dispatchar = request.getRequestDispatcher("/WEB-INF/lib/view/studentRegister.jsp");
		dispatchar.forward(request,response);
		//response.sendRedirect("/studentRegister.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String nom = request.getParameter("nom");
		String prenom = request.getParameter("prenom");
		String filiere = request.getParameter("prenom");
		
		student_controller_model.bean_student student = new student_controller_model.bean_student();
		student.setFiliere(filiere);
		student.setNom(nom);
		student.setPrenom(prenom);
		
		try {
			db.registerStudent(student);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		 //response.sendRedirect("/etudiant_complete_registration.jsp");
		jakarta.servlet.RequestDispatcher dispatchar = request.getRequestDispatcher("/WEB-INF/lib/view/etudiant_complete_registration.jsp");
		dispatchar.forward(request,response);
	}

}
